/*
C programming file for ATM project
Group 5
Test on Visual Studio Community 2015, Windows 10 v1607
Last modification: Dec 12, 2016
*/

#define _CRT_SECURE_NO_DEPRECATE
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include"linkist.h"


char *login(custinfo *head)
{
	custinfo *node1;
	char inputac[5];
	char inputpas[7];
	int count;
	printf("\t\t==================================================\n");
	printf("\t\t               Respected Customers                \n");
	printf("\t\t            Welcome to Use ATM System         	   \n");
	printf("\t\t                                                  \n");
	printf("\t\t >_< Please input your account number:");
	scanf("%s", inputac);
	//head print to node1 in memory
	node1 = head;
	while ((node1 != NULL) && (strcmp(node1->account, inputac) != 0))
	{
		node1 = node1->next;
	}
	node1 = searchByaccount(head, inputac);//find the current account which working on

	printf("\t\t >_< Please input your passward:");
	scanf("%s", inputpas);

	//judgement for the password
	for (count = 0; count < 3; count++)//limit times fo password input
	{
		if (count < 2)//you have already input onec since < 2
		{



			if (strcmp(node1->password, inputpas) == 0)//judge weather they are equal or not
				return node1->account;
			else
			{
				printf("\t\t                                                  \n");
				printf("\t\t==================================================\n");

				//reinput interface
				printf("\t\t                                                 \n");
				printf("\t\t         +_+  Wrong Passward !                   \n");
				printf("\t\t         <_<  You still have %d more time         \n", 2 - count);//the left times that you can reinput
				printf("\t\t         >_<  Please try again:");
				scanf("%s", inputpas);
				printf("\t\t                                                 \n");
				printf("\t\t==================================================\n");
			}
		}
		else
		{
			printf("\t\t===================================================");
			printf("\n");
			printf("\t\t      Sorry, The passward you entered       \n");
			printf("\t\t                 is incorrect               \n");
			printf("\t\t            PLEASE REMOVE YOUR CARD         \n");
			printf("\n");
			printf("\t\t===================================================");
			strcpy(inputac, "0000");
			return inputac;
		}
	}
}

void check(char account[], custinfo *head)
{
	//int *select;
	custinfo *accountnow;
	accountnow = (custinfo *)malloc(sizeof(custinfo));
	accountnow = searchByaccount(head, account);
	printf("		     =======================================\n");
	printf("			     >> Your blance is <<\n");
	printf("			        %f\n", accountnow->balance);
	printf("\n");
	printf("		     =======================================\n");

}

void save(char account[], custinfo *head)
{
	//this function used to save funtion
	custinfo *save;
	save = (custinfo *)malloc(sizeof(custinfo));
	save = searchByaccount(head, account);
	float saveMoney = 0;

	printf("\t\t===================================================");
	printf("\n");
	printf("\t\t  --> Please input the amount of cash <--  \n");
	printf("                   Amount:                   ");
	printf("\n");
	printf("\t\t===================================================\n");


	printf("\t\tPlease input money you want to save");
	scanf("%f", &saveMoney);
	save->balance = save->balance + saveMoney;
	printf("\t\tSUCCESS: Your balance now is %f\n", save->balance);

}


void withdraw(char account[], custinfo *head)
{
	//this function used to withdraw function
	custinfo *withdraw;
	withdraw = head;
	float withdrawMoney = 0;
	if (withdraw->level == 'N')
	{
		printf("Your account is Not VIP, you can withdraw at most 2000 per time \n\n\n");
	}
	if (withdraw->level == 'V')
	{
		printf("Your account is VIP, you can withdraw at most 3000 per time \n\n\n");
	}
	printf("\t\t===================================================");
	printf("\n");
	printf("\t\t  --> Please input the amount of cash <--  \n");
	printf("                   Amount:                   ");
	printf("\n");
	printf("\t\t===================================================\n");

	printf("\t\tPlease input money you want to withdraw");
	scanf("%f", &withdrawMoney);
	if ((withdraw->balance - withdrawMoney >= 0) && (withdraw->level == 'N') && (withdrawMoney <= 2000))
	{
		withdraw->balance = withdraw->balance - withdrawMoney;
		printf("\t\tSUCCESS: You have withdraw %f\n\n", withdrawMoney);
	}
	if ((withdraw->balance - withdrawMoney >= 0) && (withdraw->level == 'V') && (withdrawMoney <= 3000))
	{
		withdraw->balance = withdraw->balance - withdrawMoney;
		printf("\t\tSUCCESS: You have withdraw %f\n\n", withdrawMoney);
	}
	else
	{
		printf("\t\tERROE: Your balance is not enough or out of the range\n\n");
	}
}

void transfer(char account[], custinfo *head)
{
	//this function used to transfer function
	custinfo *from, *to;
	float transfer = -1;
	from = (custinfo *)malloc(sizeof(custinfo));
	to = (custinfo *)malloc(sizeof(custinfo));
	char toAccount[5];
	from = searchByaccount(head, account);
	if (from->level == 'N')
	{
		printf("Your account is Not VIP, you can transfer at most 10000 and charge is 1%% \n\n\n");
	}
	if (from->level == 'V')
	{
		printf("Your account is VIP, you can transfer at most 20000 and charge is 0.5%% \n\n\n");
	}
	printf("\t\t===================================================");
	printf("\n");
	printf("\t\t  --> Please input the account ID you want to transfer <--  \n");
	printf("                   ID:                   ");
	scanf("%s", toAccount);
	to = searchByaccount(head, toAccount);
	printf("You will transfer to %s\n\n\n", to->name);
	while (transfer != 0)
	{
		printf("\n\n\n");
		printf("\t\t===================================================");
		printf("\n");
		printf("\t\t  --> Input the money you want to transfer: ");
		scanf("%f", &transfer);
		if ((from->balance - (transfer *1.01) >= 0) && (from->level == 'N') && (transfer <= 10000))
		{
			from->balance = from->balance - (transfer * 1.01);
			to->balance = to->balance + transfer;
			printf("\t\tSUCCESS: Your balance now is %f\n\n", from->balance);
			break;
		}
		if ((from->balance - (transfer *1.005) >= 0) && (from->level == 'V') && (transfer <= 20000))
		{
			from->balance = from->balance - (transfer * 1.005);
			to->balance = to->balance + transfer;
			printf("\t\tSUCCESS: Your balance now is %f\n\n", from->balance);
			break;
		}
		else
		{
			printf("\t\tERROE: Your balance is not enough or out of the range\n\n");
		}
	}
	//printLinklist(head);
}


//quit function: write the txt and also exit the program, close the point and file
//quit()
void quit(custinfo *head)
{
	//quit function used to end the program
	FILE *fp;
	custinfo *current, *next;
	fp = fopen("account.txt", "w+"); //when the program is finish, w will change to w+, file name also change to account.txt
	current = (custinfo *)malloc(sizeof(custinfo));
	next = (custinfo *)malloc(sizeof(custinfo));
	current = head;
	while (current != NULL) //uesd loop to write the file
	{
		next = current->next;
		fprintf(fp, "%s %s %s %f %c\n", current->account, current->name, current->password, current->balance, current->level);
		current = next;
	}
	free(current);
	free(next);
	fclose(fp); //close the file point
	listDelete(head); //delete the linklist
	exit(0);

}




void function_list(char account[], custinfo *head)
{
	//here is for the function_list
	//input the function number and jump to that funcion
	int *choose;
	choose = (int *)malloc(sizeof(int));
	do
	{
		printf("\t\t|$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$|\n");
		printf("\t\t|                                               |\n");
		printf("\t\t|       Welcome to Use ATM System         	|\n");
		printf("\t\t|                                               |\n");
		printf("\t\t|    Please Select The Following Functions:     |\n");
		printf("\t\t|                                               |\n");
		printf("\t\t|   $$-Check	 -- Press 1			|\n");
		printf("\t\t|   $$-Save      -- Press 2			|\n");
		printf("\t\t|   $$-Withdraw	 -- Press 3			|\n");
		printf("\t\t|   $$-Transfer	 -- Press 4			|\n");
		printf("\t\t|   $$-Quit      -- Press 5			|\n");
		printf("\t\t|                                               |\n");
		printf("\t\t|$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$|\n");

		printf("\n\n\n\n");

		printf("Please Input Number:");
		scanf("%d", choose);

		switch (*choose) //use switch to make function list
		{
		case 1:check(account, head);
			break;
		case 2:save(account, head);
			break;
		case 3:withdraw(account, head);
			break;
		case 4:transfer(account, head);
			break;
		case 5:free(choose);
			quit(head);
			break;
		default:printf("Please input the number 1~5\n");
			break;
		}
	} while (1);
}



//main function deal with the file read to link list, and also keep the function list run
void main()
{
	char account[5];
	FILE *fp1;
	struct custinfo *node1, *node2, *head;
	struct custinfo temp;
	fp1 = fopen("account.txt", "r");
	node1 = (struct custinfo *)malloc(sizeof(struct custinfo));
	head = node1; //point head to the node1
	if (fp1 != NULL)
	{
		fscanf(fp1, "%s%s%s%f%*c%c", node1->account, node1->name, node1->password, &node1->balance, &node1->level);
		while (fscanf(fp1, "%s%s%s%f%*c%c", temp.account, temp.name, temp.password, &temp.balance, &temp.level) != EOF)
		{
			node2 = (struct custinfo *)malloc(sizeof(struct custinfo));
			*node2 = temp;
			node1->next = node2;
			node1 = node2;
			node2->next = NULL;//keep each of the node for a whole node
		}
		fclose(fp1);
		strcpy(account, login(head)); //send the head linklist to login function
		while (strcmp(account, "0000") != 0) //check the reault from the login function
		{
			function_list(account, head); //send the head linklist to function_list
		}
		if (strcmp(account, "0000") == 0) //if the login is not pass, run quit function
		{
			quit(head);
		}
	}
	else
	{
		printf("ERROR: file not exist\n");
	}
}